package com.example.final1;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class spinner_item extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getSupportActionBar().hide();
        setContentView(R.layout.activity_spinner_item);
    }
}